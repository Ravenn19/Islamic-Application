const chapters = [
  {
    //Chapter 1
    name: "Chapter 1 - Matematika Mudah",
    questions: [
      {
        q: "Berapakah 3 + 5?",
        a: "8",
        options: ["7", "8", "9"]
      },
      {
        q: "Berapakah 10 - 4?",
        a: "6",
        options: ["5", "6", "7"]
      },
      {
        q: "Berapakah 6 × 2?",
        a: "12",
        options: ["12", "14", "10"]
      },
      {
        q: "Berapakah 12 ÷ 3?",
        a: "4",
        options: ["3", "4", "5"]
      },
      {
        q: "Berapakah 7 + 6?",
        a: "13",
        options: ["12", "13", "14"]
      },
      {
        q: "Berapakah 9 - 3?",
        a: "6",
        options: ["6", "7", "5"]
      },
      {
        q: "Berapakah 5 × 3?",
        a: "15",
        options: ["15", "10", "20"]
      },
      {
        q: "Berapakah 18 ÷ 6?",
        a: "3",
        options: ["2", "3", "4"]
      },
      {
        q: "Berapakah 8 + 4?",
        a: "12",
        options: ["11", "12", "13"]
      },
      {
        q: "Berapakah 15 - 7?",
        a: "8",
        options: ["7", "8", "9"]
      }
    ]
  },

  {
    name: "Chapter 2 - Bahasa Indonesia Mudah",
    questions: [
      {
        q: "Manakah penulisan kata yang benar?",
        a: "Apotek",
        options: ["Apotik", "Apotek", "Apoteek"]
      },
      {
        q: "Kata dasar dari 'berlari' adalah...",
        a: "Lari",
        options: ["Berlari", "Lari", "Larinya"]
      },
      {
        q: "Antonim dari kata 'tinggi' adalah...",
        a: "Rendah",
        options: ["Kecil", "Pendek", "Rendah"]
      },
      {
        q: "Sinonim dari kata 'gembira' adalah...",
        a: "Senang",
        options: ["Sedih", "Senang", "Marah"]
      },
      {
        q: "Kalimat yang benar adalah...",
        a: "Budi pergi ke pasar.",
        options: ["budi pergi ke pasar.", "Budi pergi ke pasar", "Budi pergi ke pasar."]
      },
      {
        q: "Kata yang termasuk kata kerja adalah...",
        a: "Makan",
        options: ["Piring", "Makan", "Kursi"]
      },
      {
        q: "Kata 'besar' adalah jenis kata...",
        a: "Sifat",
        options: ["Kerja", "Sifat", "Benda"]
      },
      {
        q: "Huruf kapital digunakan pada...",
        a: "Awal kalimat",
        options: ["Tengah kalimat", "Akhir kalimat", "Awal kalimat"]
      },
      {
        q: "Kalimat perintah di bawah ini adalah...",
        a: "Tolong ambilkan buku itu!",
        options: ["Saya sedang membaca buku.", "Tolong ambilkan buku itu!", "Buku itu berwarna merah."]
      },
      {
        q: "Kata sapaan yang benar adalah...",
        a: "Selamat pagi, Bu.",
        options: ["selamat pagi bu", "Selamat pagi, Bu.", "selamat Pagi Bu."]
      }
    ]
  },

  {
    name: "Chapter 3 - IPA Mudah",
    questions: [
      {
        q: "Bagian tumbuhan yang menyerap air dari tanah adalah...",
        a: "Akar",
        options: ["Daun", "Akar", "Batang"]
      },
      {
        q: "Matahari terbit dari arah...",
        a: "Timur",
        options: ["Barat", "Selatan", "Timur"]
      },
      {
        q: "Benda yang menghasilkan cahaya sendiri disebut...",
        a: "Sumber cahaya",
        options: ["Cermin", "Sumber cahaya", "Bayangan"]
      },
      {
        q: "Air akan mendidih pada suhu...",
        a: "100°C",
        options: ["0°C", "100°C", "50°C"]
      },
      {
        q: "Bagian tubuh manusia yang digunakan untuk melihat adalah...",
        a: "Mata",
        options: ["Hidung", "Telinga", "Mata"]
      },
      {
        q: "Jenis hewan yang berkembang biak dengan bertelur adalah...",
        a: "Ayam",
        options: ["Kucing", "Ayam", "Sapi"]
      },
      {
        q: "Contoh benda yang mengapung di air adalah...",
        a: "Kayu",
        options: ["Batu", "Kayu", "Logam"]
      },
      {
        q: "Planet tempat kita tinggal adalah...",
        a: "Bumi",
        options: ["Mars", "Bumi", "Venus"]
      },
      {
        q: "Proses perubahan air menjadi uap disebut...",
        a: "Penguapan",
        options: ["Pembekuan", "Pencairan", "Penguapan"]
      },
      {
        q: "Alat untuk mengukur suhu adalah...",
        a: "Termometer",
        options: ["Penggaris", "Termometer", "Jam"]
      }
    ]
  },

  {
    name: "Chapter 4 - Penalaran Mudah",
    questions: [
      {
        q: "Jika hari ini Senin, maka 2 hari lagi adalah...",
        a: "Rabu",
        options: ["Selasa", "Rabu", "Kamis"]
      },
      {
        q: "Urutan angka: 2, 4, 6, ..., 10. Angka yang hilang adalah...",
        a: "8",
        options: ["7", "8", "9"]
      },
      {
        q: "Jika 1 minggu = 7 hari, maka 2 minggu = ... hari",
        a: "14",
        options: ["10", "14", "12"]
      },
      {
        q: "Bulan setelah Maret adalah...",
        a: "April",
        options: ["Februari", "April", "Mei"]
      },
      {
        q: "Andi lahir tahun 2015. Sekarang tahun 2025. Umur Andi adalah...",
        a: "10",
        options: ["9", "10", "11"]
      },
      {
        q: "Kucing adalah hewan. Semua hewan bernapas. Maka kucing...",
        a: "Bernapas",
        options: ["Bernapas", "Berbicara", "Berjalan"]
      },
      {
        q: "Jika 5 + 5 = 10, maka 10 + 10 = ...",
        a: "20",
        options: ["15", "20", "25"]
      },
      {
        q: "Jam 3 sore ditambah 3 jam menjadi jam...",
        a: "6 sore",
        options: ["5 sore", "6 sore", "7 sore"]
      },
      {
        q: "Ayam memiliki 2 kaki. Jika ada 3 ayam, jumlah kakinya adalah...",
        a: "6",
        options: ["4", "6", "8"]
      },
      {
        q: "Jika sebuah buku berharga Rp10.000, berapa harga 2 buku?",
        a: "Rp20.000",
        options: ["Rp15.000", "Rp20.000", "Rp25.000"]
      }
    ]
  },

  {
    name: "Chapter 5 - Simbol Mudah",
    questions: [
      {
        q: "Simbol hati biasanya berarti...",
        a: "Cinta",
        options: ["Marah", "Cinta", "Takut"]
      },
      {
        q: "Simbol ☀️ melambangkan...",
        a: "Matahari",
        options: ["Bulan", "Matahari", "Bintang"]
      },
      {
        q: "Jika 🔺 = 3 sisi, maka 🔵 memiliki...",
        a: "0 sisi",
        options: ["3 sisi", "4 sisi", "0 sisi"]
      },
      {
        q: "Pola: ▲, ●, ▲, ●, ..., selanjutnya adalah...",
        a: "▲",
        options: ["●", "▲", "■"]
      },
      {
        q: "Simbol rambu lalu lintas 🚫 berarti...",
        a: "Dilarang",
        options: ["Boleh", "Berhenti", "Dilarang"]
      },
      {
        q: "Jika kotak = 4 sisi, segitiga = 3 sisi, maka lingkaran = ... sisi",
        a: "0",
        options: ["1", "0", "Tak hingga"]
      },
      {
        q: "Simbol ♻️ berarti...",
        a: "Daur ulang",
        options: ["Berbahaya", "Daur ulang", "Panas"]
      },
      {
        q: "Emoji 😴 biasanya digunakan saat seseorang merasa...",
        a: "Mengantuk",
        options: ["Marah", "Senang", "Mengantuk"]
      },
      {
        q: "Pola: 🔵, 🔴, 🔵, 🔴, ..., selanjutnya adalah...",
        a: "🔵",
        options: ["🔴", "🔵", "⚫"]
      },
      {
        q: "Simbol 'keranjang sampah' artinya...",
        a: "Buang sampah pada tempatnya",
        options: ["Boleh makan", "Bahaya", "Buang sampah pada tempatnya"]
      }
    ]
  },

  {
    name: "Chapter 6 - Pengetahuan Umum Mudah",
    questions: [
      {
        q: "Presiden pertama Indonesia adalah...",
        a: "Ir. Soekarno",
        options: ["Joko Widodo", "Ir. Soekarno", "BJ Habibie"]
      },
      {
        q: "Bendera negara Indonesia berwarna...",
        a: "Merah dan putih",
        options: ["Merah dan putih", "Putih dan biru", "Merah dan hijau"]
      },
      {
        q: "Ibukota Indonesia adalah...",
        a: "Jakarta",
        options: ["Surabaya", "Bandung", "Jakarta"]
      },
      {
        q: "Hari Kemerdekaan Indonesia diperingati setiap tanggal...",
        a: "17 Agustus",
        options: ["1 Juni", "17 Agustus", "28 Oktober"]
      },
      {
        q: "Warna dasar seragam SD adalah...",
        a: "Putih dan merah",
        options: ["Putih dan biru", "Putih dan merah", "Putih dan abu-abu"]
      },
      {
        q: "Negara tetangga Indonesia yang terkenal dengan Menara Petronas adalah...",
        a: "Malaysia",
        options: ["Singapura", "Thailand", "Malaysia"]
      },
      {
        q: "Pulau terbesar di Indonesia adalah...",
        a: "Kalimantan",
        options: ["Sumatra", "Kalimantan", "Jawa"]
      },
      {
        q: "Binatang langka khas Indonesia yang disebut komodo hidup di pulau...",
        a: "Flores",
        options: ["Sumatra", "Bali", "Flores"]
      },
      {
        q: "Uang kertas Rp1.000 berwarna dominan...",
        a: "Hijau",
        options: ["Hijau", "Merah", "Biru"]
      },
      {
        q: "Alat musik angklung berasal dari daerah...",
        a: "Jawa Barat",
        options: ["Bali", "Jawa Barat", "Sumatra Utara"]
      }
    ]
  },

  {
    name: "Chapter 7 - Life Skills Mudah",
    questions: [
      {
        q: "Sebelum makan, kita sebaiknya...",
        a: "Cuci tangan",
        options: ["Tidur", "Cuci tangan", "Main dulu"]
      },
      {
        q: "Setelah buang air kecil, kita harus...",
        a: "Membilas dan cuci tangan",
        options: ["Langsung pergi", "Main air", "Membilas dan cuci tangan"]
      },
      {
        q: "Ketika mendengar alarm kebakaran, kita harus...",
        a: "Segera keluar ruangan",
        options: ["Bersembunyi", "Segera keluar ruangan", "Menonton TV"]
      },
      {
        q: "Kebiasaan menyikat gigi dilakukan...",
        a: "Pagi dan malam hari",
        options: ["Sekali seminggu", "Pagi dan malam hari", "Hanya saat libur"]
      },
      {
        q: "Kalau lantai basah, sebaiknya kita...",
        a: "Berjalan hati-hati",
        options: ["Berlari", "Melompat", "Berjalan hati-hati"]
      },
      {
        q: "Sampah plastik sebaiknya dibuang di tempat...",
        a: "Sampah anorganik",
        options: ["Sampah organik", "Sampah anorganik", "Sembarang"]
      },
      {
        q: "Saat ada teman jatuh, kita sebaiknya...",
        a: "Menolong",
        options: ["Menertawakan", "Menolong", "Pergi"]
      },
      {
        q: "Ketika menyeberang jalan, kita harus melihat ke arah...",
        a: "Kiri dan kanan",
        options: ["Depan", "Kiri dan kanan", "Atas"]
      },
      {
        q: "Jika bangun tidur, hal pertama yang baik dilakukan adalah...",
        a: "Merapikan tempat tidur",
        options: ["Main HP", "Tidur lagi", "Merapikan tempat tidur"]
      },
      {
        q: "Agar tidak terlambat ke sekolah, kita harus...",
        a: "Bangun lebih pagi",
        options: ["Bangun siang", "Bangun lebih pagi", "Tidak mandi"]
      }
    ]
  },

  {
    name: "Chapter 8 - Bahasa Indonesia Mudah",
    questions: [
      {
        q: "Kata 'makan' adalah jenis kata...",
        a: "Kerja",
        options: ["Kerja", "Benda", "Sifat"]
      },
      {
        q: "Kata yang berlawanan dengan 'panas' adalah...",
        a: "Dingin",
        options: ["Hangat", "Dingin", "Terang"]
      },
      {
        q: "Kata 'besar' jika diubah menjadi kata kecil adalah...",
        a: "Kecil",
        options: ["Sedang", "Luas", "Kecil"]
      },
      {
        q: "Kalimat tanya biasanya diakhiri dengan tanda...",
        a: "Tanya (?)",
        options: ["Titik", "Tanya (?)", "Seru (!)"]
      },
      {
        q: "Kalimat: 'Saya pergi ke sekolah.' Subjeknya adalah...",
        a: "Saya",
        options: ["Sekolah", "Pergi", "Saya"]
      },
      {
        q: "Sinonim dari kata 'gembira' adalah...",
        a: "Senang",
        options: ["Sedih", "Senang", "Marah"]
      },
      {
        q: "Kata benda di kalimat 'Kucing tidur di kasur' adalah...",
        a: "Kucing dan kasur",
        options: ["Tidur", "Di", "Kucing dan kasur"]
      },
      {
        q: "Kalimat 'Budi membaca buku' adalah kalimat...",
        a: "Aktif",
        options: ["Pasif", "Aktif", "Tanya"]
      },
      {
        q: "Huruf kapital digunakan pada...",
        a: "Awal kalimat dan nama orang",
        options: ["Akhir kalimat", "Semua kata", "Awal kalimat dan nama orang"]
      },
      {
        q: "Antonim dari kata 'tinggi' adalah...",
        a: "Rendah",
        options: ["Pendek", "Rendah", "Kecil"]
      }
    ]
  },

  {
    name: "Chapter 9 - Bahasa Inggris Mudah",
    questions: [
      {
        q: "Apa arti kata 'apple' dalam Bahasa Indonesia?",
        a: "Apel",
        options: ["Pisang", "Apel", "Jeruk"]
      },
      {
        q: "Warna 'blue' artinya...",
        a: "Biru",
        options: ["Merah", "Kuning", "Biru"]
      },
      {
        q: "Apa arti 'cat'?",
        a: "Kucing",
        options: ["Anjing", "Kucing", "Ikan"]
      },
      {
        q: "Bahasa Inggris dari 'sekolah' adalah...",
        a: "School",
        options: ["Office", "School", "House"]
      },
      {
        q: "Angka 'five' berarti...",
        a: "Lima",
        options: ["Empat", "Lima", "Enam"]
      },
      {
        q: "Bahasa Inggris dari 'roti' adalah...",
        a: "Bread",
        options: ["Rice", "Bread", "Cake"]
      },
      {
        q: "Apa arti kata 'happy'?",
        a: "Senang",
        options: ["Sedih", "Marah", "Senang"]
      },
      {
        q: "Bahasa Inggris dari 'air' adalah...",
        a: "Water",
        options: ["Water", "Wind", "Fire"]
      },
      {
        q: "‘Green’ adalah warna...",
        a: "Hijau",
        options: ["Hijau", "Hitam", "Putih"]
      },
      {
        q: "Bahasa Inggris dari 'ibu' adalah...",
        a: "Mother",
        options: ["Sister", "Mother", "Father"]
      }
    ]
  },

  {
    name: "Chapter 10 - Campuran Level Sedang",
    questions: [
      {
        q: "3 × 4 + 2 = ...",
        a: "14",
        options: ["12", "14", "18"]
      },
      {
        q: "Bagian tubuh yang digunakan untuk bernapas adalah...",
        a: "Hidung",
        options: ["Telinga", "Mata", "Hidung"]
      },
      {
        q: "Kalimat 'Bola itu ditendang oleh Dani' adalah kalimat...",
        a: "Pasif",
        options: ["Aktif", "Pasif", "Tanya"]
      },
      {
        q: "Bahasa Inggris dari 'matahari' adalah...",
        a: "Sun",
        options: ["Moon", "Sun", "Star"]
      },
      {
        q: "Jika kamu melihat kabel listrik putus di jalan, kamu sebaiknya...",
        a: "Menjauh dan lapor orang dewasa",
        options: ["Main-main", "Menjauh dan lapor orang dewasa", "Ambil sendiri"]
      },
      {
        q: "Lawan kata dari 'cepat' adalah...",
        a: "Lambat",
        options: ["Lambat", "Ringan", "Panjang"]
      },
      {
        q: "Negara dengan bendera berwarna merah putih horizontal adalah...",
        a: "Indonesia",
        options: ["Thailand", "Indonesia", "Malaysia"]
      },
      {
        q: "5 + (6 × 2) = ...",
        a: "17",
        options: ["22", "17", "16"]
      },
      {
        q: "Bagian tumbuhan yang menyerap air dari tanah adalah...",
        a: "Akar",
        options: ["Batang", "Akar", "Daun"]
      },
      {
        q: "Jika kamu ingin ke kamar mandi, kamu sebaiknya berkata...",
        a: "\"Permisi, saya ingin ke kamar mandi.\"",
        options: [
          "\"Saya pergi saja.\"",
          "\"Permisi, saya ingin ke kamar mandi.\"",
          "\"Nggak usah bilang.\""
        ]
      }
    ]
  },

  {
    name: "Chapter 11 - Campuran Level Sulit",
    questions: [
      {
        q: "Sebuah segitiga memiliki panjang alas 10 cm dan tinggi 6 cm. Luasnya adalah...",
        a: "30 cm²",
        options: ["60 cm²", "30 cm²", "40 cm²"]
      },
      {
        q: "Air berubah menjadi uap saat...",
        a: "Dipanaskan",
        options: ["Didiamkan", "Dipanaskan", "Didinginkan"]
      },
      {
        q: "Kalimat yang mengandung kata keterangan waktu adalah...",
        a: "Adi belajar setiap malam.",
        options: ["Adi sedang duduk.", "Adi belajar setiap malam.", "Adi membaca buku."]
      },
      {
        q: "‘They are playing in the garden.’ Kata 'they' adalah...",
        a: "Subject (subjek)",
        options: ["Verb", "Object", "Subject (subjek)"]
      },
      {
        q: "Saat terjadi gempa bumi, hal terbaik yang dilakukan adalah...",
        a: "Berlindung di bawah meja",
        options: ["Keluar lari", "Berlindung di bawah meja", "Tidur saja"]
      },
      {
        q: "Satu liter air sama dengan berapa mililiter?",
        a: "1000 ml",
        options: ["100 ml", "1000 ml", "10 ml"]
      },
      {
        q: "Hewan yang berkembang biak dengan cara bertelur disebut...",
        a: "Ovipar",
        options: ["Vivipar", "Ovipar", "Mamalia"]
      },
      {
        q: "Kata baku dari 'aktifitas' adalah...",
        a: "Aktivitas",
        options: ["Aktifitas", "Aktivitas", "Aktifvitas"]
      },
      {
        q: "Bahasa Inggris dari 'dia laki-laki sedang membaca buku' adalah...",
        a: "He is reading a book.",
        options: ["He reads book.", "He is read book.", "He is reading a book."]
      },
      {
        q: "Kalau ada orang pingsan di depanmu, kamu harus...",
        a: "Minta bantuan orang dewasa atau petugas",
        options: ["Membiarkan saja", "Kasih minum langsung", "Minta bantuan orang dewasa atau petugas"]
      }
    ]
  },


];

let currentChapter = 0;
let currentQuestion = 0;
let score = 0;
let timeLeft = 15;
let timerInterval;

// DOM Elements
const modal = document.getElementById('modal');
const quizContainer = document.getElementById('quiz-container');
const chapterTitle = document.getElementById('chapterTitle');
const questionEl = document.getElementById('question');
const optionsEl = document.getElementById('options');
const nextBtn = document.getElementById('nextBtn');
const resultBox = document.getElementById('resultBox');
const resultTitle = document.getElementById('resultTitle');
const scoreText = document.getElementById('scoreText');
const retryBtn = document.getElementById('retryBtn');
const correctSound = document.getElementById('correctSound');
const wrongSound = document.getElementById('wrongSound');
const timerBox = document.getElementById('timer');

document.getElementById('start-btn').onclick = () => {
  modal.style.display = "none";
  quizContainer.classList.remove('hidden');
  startChapter();
};

retryBtn.onclick = () => startChapter();
nextBtn.onclick = () => handleNext();

function startChapter() {
  currentQuestion = 0;
  score = 0;
  resultBox.classList.add('hidden');
  quizContainer.querySelector('#quizBox').classList.remove('hidden');
  nextBtn.disabled = true;
  loadQuestion();
}

function loadQuestion() {
  clearInterval(timerInterval);
  const ch = chapters[currentChapter];
  const q = ch.questions[currentQuestion];

  if (!q) {
    showResult();
    return;
  }

  chapterTitle.textContent = ch.name;
  questionEl.textContent = q.q;
  optionsEl.innerHTML = '';
  nextBtn.disabled = true;

  q.options.forEach(opt => {
    const btn = document.createElement('button');
    btn.classList.add('fade-in');
    btn.textContent = opt;
    btn.onclick = () => selectAnswer(btn, opt, q.a);
    optionsEl.appendChild(btn);
  });

  startTimer(); // ⏳ Mulai timer setiap load soal
}

function selectAnswer(btn, selected, correct) {
  clearInterval(timerInterval);

  const allButtons = optionsEl.querySelectorAll('button');
  allButtons.forEach(b => b.disabled = true);

  if (selected === correct) {
    score++;
    btn.classList.add('correct');
    correctSound?.play();
  } else {
    btn.classList.add('wrong');
    wrongSound?.play();
    allButtons.forEach(b => {
      if (b.textContent === correct) b.classList.add('correct');
    });
  }

  nextBtn.disabled = false;
}

function handleNext() {
  currentQuestion++;
  if (currentQuestion < chapters[currentChapter].questions.length) {
    loadQuestion();
  } else {
    showResult();
  }
}

// Variabel baru untuk tombol
const nextChapterBtn = document.getElementById('nextChapterBtn');

function showResult() {
  clearInterval(timerInterval);
  quizContainer.querySelector('#quizBox').classList.add('hidden');
  resultBox.classList.remove('hidden');

  const total = chapters[currentChapter].questions.length;
  const percent = Math.round((score / total) * 100);
  scoreText.textContent = `Skor: ${percent}% (${score}/${total})`;

  // Sembunyikan semua tombol dulu
  retryBtn.style.display = 'none';
  nextChapterBtn.style.display = 'none';

  if (percent >= 30) {
    resultTitle.textContent = "Hebat! Lanjut ke chapter berikutnya 🎉";
    
    if (currentChapter < chapters.length - 1) {
      nextChapterBtn.style.display = 'inline-block';
    } else {
      nextChapterBtn.style.display = 'inline-block';
      nextChapterBtn.textContent = 'Selesai';
    }
  } else {
    resultTitle.textContent = "Ayo coba lagi!";
    retryBtn.style.display = 'inline-block';
  }
}

// Event listeners yang benar
retryBtn.addEventListener('click', startChapter);
nextChapterBtn.addEventListener('click', () => {
  if (currentChapter < chapters.length - 1) {
    currentChapter++;
    startChapter();
  } else {
    endQuiz();
  }
});

function endQuiz() {
  quizContainer.innerHTML = `
    <div class="end-screen">
      <h2>🎉 Kamu telah menyelesaikan semua chapter!</h2>
      <p>Terima kasih ya sudah bermain. Semoga bermanfaat 😊</p>
      <button id="restartBtn">Main Lagi</button>
    </div>`;
  
  document.getElementById('restartBtn').addEventListener('click', () => {
    location.reload();
  });
}

function startTimer() {
  clearInterval(timerInterval);
  timeLeft = 15;
  timerBox.textContent = timeLeft;
  timerBox.style.color = '#2d3436';

  timerInterval = setInterval(() => {
    timeLeft--;
    timerBox.textContent = timeLeft;

    if (timeLeft <= 5) timerBox.style.color = 'red';

    if (timeLeft <= 0) {
      clearInterval(timerInterval);
      alert("Waktu habis! Lanjut ke soal berikutnya.");
      handleNext(); // langsung lanjut soal
    }
  }, 1000);
}


